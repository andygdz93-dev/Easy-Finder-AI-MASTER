
import { useState } from "react";

export default function App() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");

  async function callAPI(endpoint, body) {
    const res = await fetch(`${import.meta.env.VITE_API_URL}${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    setResult(JSON.stringify(json, null, 2));
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>EasyFinder AI Dashboard</h1>

      <textarea
        rows={5}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Paste listing text or seller profile..."
        style={{ width: "100%" }}
      />

      <button onClick={() => callAPI("/ai/score-lead", { text: input })}>
        Score Lead
      </button>

      <button onClick={() => callAPI("/ai/verify-seller", { text: input })}>
        Verify Seller
      </button>

      <button onClick={() => callAPI("/ai/extract-listing", { input })}>
        Extract Listing
      </button>

      <pre
        style={{
          marginTop: 20,
          background: "#1a1a1a",
          color: "#0f0",
          padding: 10,
        }}
      >
        {result}
      </pre>
    </div>
  );
}
