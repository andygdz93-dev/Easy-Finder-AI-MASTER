# EasyFinder AI

## Overview
EasyFinder AI is an automated heavy equipment sales platform with AI scoring, live alerts, and automated buyer outreach.

## Setup & Deployment

1. Clone this repo:
   ```bash
   git clone <repo_url>
   cd EasyFinderAI/app
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create `.env` file based on `.env.example`:
   ```
   EMAIL_HOST=smtp.example.com
   EMAIL_PORT=587
   EMAIL_USER=you@example.com
   EMAIL_PASS=yourpassword
   ```

4. Run locally:
   ```bash
   python main.py
   ```

5. Deployment:
   - Push to GitHub.
   - Connect repo to Railway.
   - Railway automatically installs dependencies and runs `main.py`.

## Endpoints
- `/` – Test server running
- `/send-nda` – POST JSON `{ "email": "recipient@example.com", "name": "John" }`

    ## Advanced AI Features (added)

"
    The project now includes 4 advanced AI modules and corresponding endpoints:

"
    - `/ai/score-lead` - POST `{ "text": "<listing text>" }` -> returns lead score JSON
"
    - `/ai/extract-listing` - POST `{ "input": "<url or listing text>" }` -> returns structured listing JSON
"
    - `/ai/outreach` - POST `{ "listing": {...}, "buyer": {...}, "tone": "professional" }` -> returns 3-email outreach sequence
"
    - `/ai/verify-seller` - POST `{ "text": "<seller text or profile>" }` -> returns fraud suspicion JSON

"
    **Notes**:
"
    - These modules call the `ai_engine` which uses the OPENAI_API_KEY environment variable. Set `OPENAI_API_KEY` in your `.env`.
"
    - The AI attempts to return pure JSON. If the model returns text around the JSON, the code attempts to clean and parse it; you may need to adapt prompts and parsing for best reliability.
"
