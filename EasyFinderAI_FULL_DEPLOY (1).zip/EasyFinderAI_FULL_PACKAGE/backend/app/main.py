from flask import Flask, request, jsonify
from utils.email_automation import send_nda_email
import os

app = Flask(__name__)

@app.route('/')
def home():
    return "EasyFinder AI Running!"

@app.route('/send-nda', methods=['POST'])
def send_nda():
    data = request.json or {}
    recipient_email = data.get('email')
    recipient_name = data.get('name', 'Recipient')
    if not recipient_email:
        return jsonify({'status': 'failure', 'reason': 'missing email'}), 400
    result = send_nda_email(recipient_email, recipient_name)
    return jsonify({'status': result})


# --- AI feature endpoints ---
from utils.ai_lead_scoring import score_lead
from utils.listing_extractor import extract_listing
from utils.outreach_automation import generate_outreach_sequence
from utils.seller_verification import verify_seller

@app.route('/ai/score-lead', methods=['POST'])
def ai_score_lead():
    data = request.json or {}
    text = data.get('text', '')
    if not text:
        return jsonify({'status': 'failure', 'reason': 'missing text'}), 400
    result = score_lead(text)
    return jsonify({'status': 'success', 'result': result})

@app.route('/ai/extract-listing', methods=['POST'])
def ai_extract_listing():
    data = request.json or {}
    input_text = data.get('input', '')
    if not input_text:
        return jsonify({'status': 'failure', 'reason': 'missing input'}), 400
    result = extract_listing(input_text)
    return jsonify({'status': 'success', 'result': result})

@app.route('/ai/outreach', methods=['POST'])
def ai_outreach():
    data = request.json or {}
    listing = data.get('listing', {})
    buyer = data.get('buyer', None)
    tone = data.get('tone', 'professional')
    result = generate_outreach_sequence(listing, buyer, tone)
    return jsonify({'status': 'success', 'result': result})

@app.route('/ai/verify-seller', methods=['POST'])
def ai_verify_seller():
    data = request.json or {}
    text = data.get('text', '')
    if not text:
        return jsonify({'status': 'failure', 'reason': 'missing text'}), 400
    result = verify_seller(text)
    return jsonify({'status': 'success', 'result': result})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
