    from utils.ai_engine import ai_reply
    import json

    def extract_listing(url_or_text: str):
        prompt = (
            "You are a data extractor for heavy equipment listings. Given either a listing URL or the full listing text, "
            "extract the following fields as JSON: title, make, model, year, hours_or_miles, price, location, seller_type (dealer/private), "
            "condition_summary (one short sentence), and images (list of image URLs if available). If a field is missing, set it to null.

"
            "Input:\n"""\n" + url_or_text + "\n"""

"
            "Return ONLY a JSON object."
        )
        ai_out = ai_reply(prompt)
        try:
            cleaned = ai_out.strip().strip('`').strip()
            return json.loads(cleaned)
        except Exception as e:
            return {"error": "AI parse error", "raw_ai": ai_out}
