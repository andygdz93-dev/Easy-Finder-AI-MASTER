from utils.ai_engine import ai_reply
import json

def generate_outreach_sequence(listing_data: dict, buyer_profile: dict=None, tone: str='professional'):
    # listing_data expected to contain keys like title, make, model, year, price, location
    prompt = (
        "You are a senior sales copywriter specialized in heavy equipment sales.\n"
        "Given the listing data (JSON) and an optional buyer profile (JSON), generate a 3-email outreach sequence: initial contact, follow-up #1, follow-up #2.\n"
        "Each email should include subject and body fields. Keep them short, persuasive, and include a clear CTA to schedule a demo or reply. Tone: %s.\n\n"
        "Listing JSON:\n"""\n" + json.dumps(listing_data) + "\n"""\n\n"
        "Buyer JSON:\n"""\n" + (json.dumps(buyer_profile) if buyer_profile else "null") + "\n"""\n\n"
        "Return ONLY a JSON object with keys: emails (list of 3 objects with subject and body)."
    ) % tone

    ai_out = ai_reply(prompt)
    try:
        cleaned = ai_out.strip().strip('`').strip()
        return json.loads(cleaned)
    except Exception as e:
        return {"error": "AI parse error", "raw_ai": ai_out}
