from utils.ai_engine import ai_reply

def verify_seller(listing_text_or_profile: str):
    prompt = (
        "You are a fraud-detection assistant for heavy equipment listings. Given the listing text or seller profile,\n"
        "assess the likelihood of scam or fraud on a scale 0-100 where 0 means very safe and 100 means highly suspicious.\n"
        "Return a JSON object with keys: suspicion_score (0-100), flags (list of strings explaining concerns), and recommendation (one short sentence).\n\n"
        "Input:\n"""\n" + listing_text_or_profile + "\n"""

        "Respond with ONLY the JSON object."
    )
    ai_out = ai_reply(prompt)
    import json
    try:
        cleaned = ai_out.strip().strip('`').strip()
        return json.loads(cleaned)
    except Exception as e:
        return {"error": "AI parse error", "raw_ai": ai_out}
