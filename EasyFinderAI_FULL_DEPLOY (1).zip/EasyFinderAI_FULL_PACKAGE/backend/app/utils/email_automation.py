import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
from config.config import EMAIL_HOST, EMAIL_PORT, EMAIL_USER, EMAIL_PASS

def send_nda_email(to_email, recipient_name):
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = 'Sign NDA & Schedule Demo – EasyFinder AI'
        msg['From'] = EMAIL_USER
        msg['To'] = to_email

        template_path = os.path.join(os.path.dirname(__file__), '..', '..', 'templates', 'nda_email.html')
        template_path = os.path.abspath(template_path)
        with open(template_path, 'r', encoding='utf-8') as f:
            html_content = f.read().replace('[Recipient Name]', recipient_name)

        msg.attach(MIMEText(html_content, 'html'))

        server = smtplib.SMTP(EMAIL_HOST, int(EMAIL_PORT))
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASS)
        server.sendmail(EMAIL_USER, to_email, msg.as_string())
        server.quit()
        return 'success'
    except Exception as e:
        print('Error sending email:', e)
        return f'failure: {e}'
