    from utils.ai_engine import ai_reply
    import json

    def score_lead(listing_text: str):
        prompt = (
            "You are an expert evaluator for heavy equipment listings. Given the listing text, "
            "return a JSON object with the following keys:
"
            " - score: integer 0-100 (higher is better lead)
"
            " - reasons: list of short strings explaining the scoring
"
            " - category: one of ["Excellent", "Good", "Fair", "Poor"]

"
            "Listing text:\n"""\n" + listing_text + "\n"""

"
            "Respond with only the JSON object and nothing else."
        )
        ai_out = ai_reply(prompt)
        # Try to parse AI output as JSON; if it fails, return a fallback structured output.
        try:
            # Some LLMs may wrap JSON in backticks; strip them.
            cleaned = ai_out.strip().strip('`').strip()
            return json.loads(cleaned)
        except Exception as e:
            return {
                "score": 50,
                "reasons": ["AI parse error: fallback mid-score"],
                "category": "Fair",
                "raw_ai": ai_out
            }
