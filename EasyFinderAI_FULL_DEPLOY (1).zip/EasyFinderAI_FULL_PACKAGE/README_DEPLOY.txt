
EASYFINDER AI – COMPLETE DEPLOY PACKAGE
=======================================

CONTENTS:
- backend/ → Full Flask backend with AI modules
- frontend/ → React UI to interact with AI endpoints
- README_DEPLOY.txt → Deployment instructions

BACKEND DEPLOYMENT (RAILWAY)
-----------------------------
1. Upload backend folder to GitHub.
2. Connect repo to Railway → New Project → Deploy from GitHub.
3. Add environment variables:

    PORT=8000
    EMAIL_HOST=smtp.gmail.com
    EMAIL_PORT=587
    EMAIL_USER=your-email
    EMAIL_PASS=your-app-password
    OPENAI_API_KEY=your-key
    OPENAI_MODEL=gpt-4o-mini

4. Railway detects Python & deploys automatically.

FRONTEND DEPLOYMENT (VERCEL)
------------------------------
1. Upload frontend folder to GitHub (separate repo recommended).
2. Go to Vercel → New Project → Import Repo.
3. Add environment variable:

    VITE_API_URL=https://<your-railway-url>

4. Deploy.

TEST ENDPOINTS
--------------
/ai/score-lead
/ai/extract-listing
/ai/outreach
/ai/verify-seller
